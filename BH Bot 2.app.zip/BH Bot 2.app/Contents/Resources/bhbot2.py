import os
import sys
import ast
import time
try:
    import thread
except:
    import _thread as thread
def receiveMessage(message):
    message = str(message).lower()
    message = ast.literal_eval(message)
    for trigger_response in triggers_responses:
        if trigger_response[0].lower() in str(message):
            sendMessage(trigger_response[1])

def sendMessage(message):
    os.system('caffeinate -ut 5')
    os.system("osascript -e 'tell application " + '"BlockheadsServer" to activate' + "'")
    time.sleep(1)
    for char in message:
        os.system('osascript -e ' + "'tell application " + '"System Events" to keystroke "' + str(char) + '"'  + "'")
    os.system('osascript -e ' + "'tell application " + '"System Events" to keystroke ' + str('return') + ''  + "'")

def readsyslog():
    global bhlog
    syslogfile = open('/private/var/log/system.log')
    syslog = syslogfile.read()
    syslogfile.close()
    syslog = syslog.replace(' ', '<spaceforpythonscript>').replace('\n', ' ').split()
    syslog = ast.literal_eval(str(syslog).replace('<spaceforpythonscript>', ' '))
    bhlog = []
    for item in syslog:
        if 'BlockheadsServer' in item:
            bhlog += [item]


def bot():
    global triggers_responses
    global bhlog
    global bot_is_running
    print('Starting bot.')
    try:
        triggers_responses = open('/Users/Shared/bhserverbotdatabase').read()
        triggers_responses = ast.literal_eval(triggers_responses)
    except:
        triggers_responses = []
        os.system('echo "[]" > /Users/Shared/bhserverbotdatabase')
    while True:
        if bot_is_running:
            readsyslog()
            log = bhlog[len(bhlog) - 1]
            log = log[log.find(']'):]
            log = log[log.find(' - '):]
            clog = log
            if ':' in log:
                olog = log
                while str(clog) == str(olog):
                    if bot_is_running:
                        time.sleep(1)
                        readsyslog()
                        clog = bhlog[len(bhlog) - 1]
                        clog = clog[clog.find(']'):]
                        clog = clog[clog.find(' - '):]
                        if str(clog) != str(log):
                            cmsg = bhlog[len(bhlog) - 1]
                            cmsg = cmsg[cmsg.find(' - '):]
                            cmsg = cmsg[cmsg.find(':'):]
                            try:
                                cmsg = cmsg[cmsg.find(cmsg[2]):]
                            except:
                                pass
                    else:
                        cmsg = ''
                        break
                receiveMessage([cmsg])
            time.sleep(1)
        else:
            print('Quitting bot.')
            break

if sys.version[:1] == '2':
    def input(message):
        return(raw_input(message))

#os.system('clear')
#print('''
#-- Menu --
#1. Run bot
#2. View triggers
#3. Add trigger
#4. Remove trigger
#5. Reset triggers
#6. Take over the world
#''')
#response = str(input('Choice: '))
#os.system('clear')
#if response == '1':
#    bot()
#elif response == '2':
#    try:
#        dbfile = open('/Users/Shared/bhserverbotdatabase')
#    except:
#        os.system('echo "[]" > /Users/Shared/bhserverbotdatabase')
#        dbfile = open('/Users/Shared/bhserverbotdatabase')
#    db = ast.literal_eval(dbfile.read())
#    dbfile.close()
#    i = 0
#    for item in db:
#        print(str(i) + '. ' + str(item))
#        i += 1
#elif response == '3':
#elif response == '4':
#    try:
#        dbfile = open('/Users/Shared/bhserverbotdatabase')
#    except:
#        os.system('echo "[]" > /Users/Shared/bhserverbotdatabase')
#        dbfile = open('/Users/Shared/bhserverbotdatabase')
#    db = ast.literal_eval(dbfile.read())
#    dbfile.close()
#    i = 0
#    for item in db:
#        print(str(i) + '. ' + str(item))
#        i += 1
#    trigger_to_remove = input('Trigger to remove: ')
#    if len(db) - 1 < int(trigger_to_remove):
#        exit('Does not exist')
#    db.pop(int(trigger_to_remove))
#    dbfile = open('/Users/Shared/bhserverbotdatabase', 'w')
#    dbfile.write(str(db))
#    dbfile.close()
#elif response == '5':
#    try:
#        dbfile = open('/Users/Shared/bhserverbotdatabase','w')
#    except:
#        os.system('echo "[]" > /Users/Shared/bhserverbotdatabase')
#        dbfile = open('/Users/Shared/bhserverbotdatabase','w')
#    dbfile.write('[]')
#    dbfile.close()
#elif response == '6':
#    exit("You're not allowed to do that!")
#elif response == '':
#    bot()
#else:
#    exit('Unknown response.')
try:
    import Tkinter as tk
except:
    import tkinter as tk
screen = 'main'
def start_bot():
    global bot_button
    global bot_is_running
    bot_button['text'] = 'Stop Bot'
    bot_button['command'] = stop_bot
    bot_is_running = True
    thread.start_new_thread(bot, ())
def stop_bot():
    global bot_button
    global bot_is_running
    bot_button['text'] = 'Start Bot'
    bot_button['command'] = start_bot
    bot_is_running = False
def add_trigger():
    trigger = add_trigger_trigger_textbox.get('1.0', tk.END)
    response = add_trigger_response_textbox.get('1.0', tk.END)
    try:
        dbfile = open('/Users/Shared/bhserverbotdatabase')
    except:
        os.system('echo "[]" > /Users/Shared/bhserverbotdatabase')
        dbfile = open('/Users/Shared/bhserverbotdatabase')
    db = ast.literal_eval(dbfile.read())
    dbfile.close()
    db += [[trigger, response]]
    print(trigger)
    dbfile = open('/Users/Shared/bhserverbotdatabase', 'w')
    dbstr = str(db)
    dbstr = dbstr.replace("u'", "'").replace('\\n', '')
    print(dbstr)
    dbfile.write(dbstr)
    dbfile.close()
    exit('Trigger Added!')
def switch_to_triggers():
    Application().triggers()
def clear_frame():
    for widget in frame.winfo_children():
        widget.destroy()
class Application(tk.Frame):
    def __init__(self, master=None):
        global screen
        tk.Frame.__init__(self, master)
        self.grid()
        if screen == 'main':
            self.mainScreen()
        elif screen == 'triggers':
            pass
    def mainScreen(self):
        global bot_button
        global gui_not_cow_label
        global add_trigger_label
        global add_trigger_scrollbar
        global add_trigger_trigger_textbox
        global add_trigger_response_textbox
        global add_trigger_button
        gui_not_cow_label = tk.Label(self, text='This GUI is not a cow!', bg='white', fg='#CD7F32')
        gui_not_cow_label.grid()
        bot_button = tk.Button(self, text='Start Bot' ,command=start_bot, bg='green', fg='white')
        bot_button.grid()
        add_trigger_label = tk.Label(self, text='-- Add trigger --')
        add_trigger_label.grid()
        add_trigger_trigger_label = tk.Label(self, text='Trigger:')
        add_trigger_trigger_label.grid()
        add_trigger_trigger_textbox = tk.Text(self, height=1, width=20, bg='grey', fg='black')
        add_trigger_trigger_textbox.grid()
        add_trigger_response_label = tk.Label(self, text='Response:')
        add_trigger_response_label.grid()
        add_trigger_response_textbox = tk.Text(self, height=1, width=20, bg='grey', fg='black')
        add_trigger_response_textbox.grid()
        add_trigger_button = tk.Button(self, text='Add trigger', command=add_trigger)
        add_trigger_button.grid()
        switch_to_triggers_button = tk.Button(self, text='View Triggers', command=switch_to_triggers)
#        switch_to_triggers_button.grid()
    def triggers():
        global triggers_boo_label
        triggers_boo_label = tk.Label(self, text='Boo!')
app = Application()
app.master.resizable(width=False, height=False)
app.master.title('Bot')
app.mainloop()
